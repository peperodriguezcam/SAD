cd /ldif
ldapadd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 01-ejemplo.ldif
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'PepeRodriguez2026id=peperodriguezcam,ou=people,dc=securecorp,dc=local"
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'PepeRodriguez2026' "uid=peperodriguezcam,ou=people,dc=securecorp,dc=local"
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'PepeRodriguez2026' "uid=peperodriguezcam,ou=people,dc=securecorp,dc=local"
ls
nano 02-tu-turno.ldif 
cat 01-ejemplo.ldif 
nano 02-tu-turno.ldif 
ls
ldapadd 02-tu-turno.ldif 
cat 01-ejemplo.ldif 
cat 02-tu-turno.ldif 
mv 02-tu-turno.ldif 03-martatorres.ldif
ls
mv 03-martatorres.ldif 02-peperodriguez.ldif
ls
mv 01-ejemplo.ldif 01-luciaromero.ldif
ls
cp 02-peperodriguez.ldif 03-martatorres.ldif
ls
nano 03-martatorres.ldif 
cat 01-luciaromero.ldif 
cat 02-peperodriguez.ldif 
cat 03-martatorres.ldif 
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'PepeRodriguez2026' "uid=peperodriguezcam,ou=people,dc=securecorp,dc=local"
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'Lucia2026' "uid=lromero,ou=people,dc=securecorp,dc=local"
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'PepeRodriguez2026' "uid=peperodriguezcam,ou=people,dc=securecorp,dc=local"
ldapwhoami -x -H ldap://ldap.securecorp.local -D
"uid=lromero,ou=people,dc=securecorp,dc=local" -w 'Lucia2026'
"uid=lromero,ou=people,dc=securecorp,dc=local" -w 'Lucia2026' -w
cat 01-luciaromero.ldif 
ldapadd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 01-ejemplo.ldif
ldapadd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 01-luciaromero.ldif 
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -s 'Lucia2026' "uid=lromero,ou=people,dc=securecorp,dc=local"
ldapadd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-peperodriguez.ldif 
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -s 'peperodriguezcam' "uid=peperodriguezcam,ou=people,dc=securecorp,dc=local"
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -s 'peperodriguezcam' "uid=peperodriguezcam,ou=people,dc=securecorp,dc=local"
ldapsearch -x -LLL -H ldap://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local"
"(objectClass=inetOrgPerson)" uid
ldapsearch -x -LLL -H ldap://ldap.securecorp.local -b "ou=admin,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" uid
nano 01-luciaromero.ldif 
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -s 'Lucia2026' "uid=lromero,ou=people,dc=securecorp,dc=local"
nano 02-peperodriguez.ldif 
nano 02-peperodriguez.ldif 
nano 03-martatorres.ldif 
nano 02-peperodriguez.ldif 
ldapadd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-peperodriguez.ldif 
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'Lucia2026' "uid=lromero,ou=people,dc=securecorp,dc=local"
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'peperodriguez2026' "uid=peperodriguezcam,ou=people,dc=securecorp,dc=local"
rm -r 03-martatorres.ldif 
ls
mv 02-tu-turno.ldif
ls
mv 02-peperodriguez.ldif 02-tu-turno.ldif
ls
nano 02-tu-turno.ldif 
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'peperodriguez2026' "uid=peperodriguezcam,ou=people,dc=securecorp,dc=local"
exit
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'peperodriguez2026' "uid=peperodriguezcam,ou=people,dc=securecorp,dc=local"
ldapsearch -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -b "ou=people,dc=securecorp,dc=local" "(uid=peperodriguezcam)"
ldapsearch -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -b "ou=people,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" uid cn
ls
ls
ls -la
cd ldif
cd ..
cd ..
cd ..
ls
cd ldif/
nano 02-tu-turno.ldif 
ldapadd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -s 'Pepe2026' "uid=peperodriguezcam,ou=people,dc=securecorp,dc=local"
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -s 'Marta2026' "uid=mtorres,ou=people,dc=securecorp,dc=local"
ls
ldapsearch -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -b "ou=people,dc=securecorp,dc=local" "(uid=peperodriguezcam)"
ldapsearch -x -LLL -H ldap://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=rrhh)" member
exit
cd ..
cd ldif/
cat 02-tu-turno.ldif 
ldapadd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f /ldif/02-tu-turno.ldif
exit
cat /pki/ca/ca.crt
ls -l /pki/ca/ca.crt
nano /etc/ldap/ldap.conf
ls
ls -la
cd  /etc/ldap/
ls
nano /etc/ldap/ldap.conf
cat /etc/ldap/ldap.conf
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=lromero,ou=people,dc=securecorp,dc=local" -w 'Lucia2026'
ldapwhoami -x -H ldap://ldap.securecorp.local -D "uid=lromero,ou=people,dc=securecorp,dc=local" -w 'Lucia2026'
exit
kinit peperodriguezcam
kvno host/...
klist
exit
kvno host/web.securecorp.local
kinit lromero
exit
kinit mtorres
exit
exit
kinit mtorres
kinit mtorres
exit
kinit mtorres
exit
cat /etc/ldap/ldap.conf 
exit
ldapsearch -x -H ldap://127.0.0.1 -D "cn=admin,dc=securecorp,dc=local" -W -b "ou=usuarios,dc=securecorp,dc=local" "uid=peperodriguezcam"
ldapsearch -x -H ldap://127.0.0.1 -D "cn=admin,dc=securecorp,dc=local" -W -b "ou=usuarios,dc=securecorp,dc=local" "(uid=peperodriguezcam)"
ldapsearch -x -H ldap://127.0.0.1 -D "cn=admin,dc=securecorp,dc=local" -W -b "ou=usuarios,dc=securecorp,dc=local" "(uid=peperodriguezcam)"
ldapsearch -x -H ldap://127.0.0.1 -D "cn=admin,dc=securecorp,dc=local" -W -b "ou=usuarios,dc=securecorp,dc=local"
ldapsearch -x -H ldap://127.0.0.1 -D "cn=admin,dc=securecorp,dc=local" -b "ou=usuarios,dc=securecorp,dc=local"
ldapsearch -x -H ldap://127.0.0.1 -D "cn=admin,dc=securecorp,dc=local" -W -b "ou=usuarios,dc=securecorp,dc=local" "(uid=peperodriguezcam)"
ldapsearch -x -H ldap://127.0.0.1 -D "cn=admin,dc=securecorp,dc=local" -W -b "ou=usuarios,dc=securecorp,dc=local" "(uid=peperodriguezcam)"
ldapsearch -x -H ldap://192.168.122.1 -D "cn=admin,dc=securecorp,dc=local" -W -b "ou=usuarios,dc=securecorp,dc=local" "(uid=peperodriguezcam)"
ldapsearch -x -H ldap://192.168.122.1 -D "cn=admin,dc=securecorp,dc=local" -W -b "ou=usuarios,dc=securecorp,dc=local"
ldapsearch -x -LLL -H ldap://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local"
"(objectClass=inetOrgPerson)" uid
ldapsearch -x -LLL -H ldap://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" uid
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" uid
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" uid
ls
exitg
exit
cd /ldif/
nano rociosantos.ldif
ls
nano 02-tu-turno.ldif 
ldapadd -x -H ldaps://ldap.securecorp.local -D "cn=admin, dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
nano rociosantos.ldif
nano 02-tu-turno.ldif 
ldapadd -x -H ldaps://ldap.securecorp.local -D "cn=admin, dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
ldapadd -x -H ldaps://ldap.securecorp.local -D "cn=admin, dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
ldapwhoami -x -H ldap://ldap.securecorp.local -D
"uid=rociosantos,ou=people,dc=securecorp,dc=local" -w 
"uid=rociosantos,ou=people,dc=securecorp,dc=local" -w 
ldapwhoami -x -H ldap://ldap.securecorp.local -D "uid=rociosantos,ou=people,dc=securecorp,dc=local" -w 
ldappasswd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W \ -s 'Rocio2026' "uid=rociosantos,ou=people,dc=securecorp,dc=local"
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W \ -s 'Rocio2026' "uid=rociosantos,ou=people,dc=securecorp,dc=local"
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -s 'Rocio2026' "uid=rociosantos,ou=people,dc=securecorp,dc=local"
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -s 'Rocio2026' "uid=rociosantos,ou=people,dc=securecorp,dc=local"
ldappasswd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -s 'Rocio2026' "uid=rociosantos,ou=people,dc=securecorp,dc=local"
ldapwhoami -x -H ldap://ldap.securecorp.local -D "uid=rociosantos,ou=people,dc=securecorp,dc=local" -w 
ldapwhoami -x -H ldap://ldap.securecorp.local -D "uid=rociosantos,ou=people,dc=securecorp,dc=local" -w 'Rocio2026'
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=rociosantos,ou=people,dc=securecorp,dc=local" -w 'Rocio2026'
exit
