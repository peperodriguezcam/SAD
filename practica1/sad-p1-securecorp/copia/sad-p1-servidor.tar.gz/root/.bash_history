mkdir -p /pki/ca && cd /pki/ca
openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:4096 -out ca.key
openssl req -x509 -new -key ca.key -sha256 -days 3650 -subj "/C=ES/O=SecureCorp/CN=SecureCorp Root CA - Pepe Rodriguez \
-addext "basicConstraints=critical,CA:TRUE" \
-addext "keyUsage=critical,keyCertSign,cRLSign" \
-out ca.crt
openssl req -x509 -new -key ca.key -sha256 -days 3650 -subj "/C=ES/O=SecureCorp/CN=SecureCorp Root CA - Pepe Rodriguez \
-addext "basicConstraints=critical,CA:TRUE" \
-addext "keyUsage=critical,keyCertSign,cRLSign" \
-out ca.crt
openssl req -x509 -new -key ca.key -sha256 -days 3650 -subj "/C=ES/O=SecureCorp/CN=Pepe Rodriguez\
-addext "basicConstraints=critical,CA:TRUE" \
-addext "keyUsage=critical,keyCertSign,cRLSign" \
-out ca.crt
openssl req -x509 -new -key ca.key -sha256 -days 3650 -subj "/C=ES/O=SecureCorp/CN=PepeRodriguez\
-addext "basicConstraints=critical,CA:TRUE" \
-addext "keyUsage=critical,keyCertSign,cRLSign" \
-out ca.crt
openssl req -x509 -new -key ca.key -sha256 -days 3650 -subj "/C=ES/O=SecureCorp/CN=PepeRodriguez
-addext "basicConstraints=critical,CA:TRUE" \
-addext "keyUsage=critical,keyCertSign,cRLSign" \
-out ca.crt
openssl req -x509 -new -key ca.key -sha256 -days 3650 -subj "/C=ES/O=SecureCorp/CN=SecureCorp Root CA - PepeRodriguez \
-addext "basicConstraints=critical,CA:TRUE" \
-addext "keyUsage=critical,keyCertSign,cRLSign" \
-out ca.crt
openssl req -x509 -new -key ca.key -sha256 -days 3650 -subj "/C=ES/O=SecureCorp/CN=SecureCorp Root CA - PepeRodriguez" -addext "basicConstraints=critical,CA:TRUE" -addext "keyUsage=critical,keyCertSign,cRLSign" -out ca.crt
exit
mkdir -p /pki/servidor && cd /pki/servidor
openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:2048 -out ldap.key
cat > ldap.ext <<'EOF'
cat > ldap.ext <<'EOF'
basicConstraints = CA:FALSEkeyUsage = critical, digitalSignature, keyEncipherment
extendedKeyUsage = serverAuth
subjectAltName = DNS:ldap.securecorp.local
EOF 

cat > ldap.ext <<'EOF'
basicConstraints = CA:FALSE
keyUsage = critical, digitalSignature, keyEncipherment
extendedKeyUsage = serverAuth
subjectAltName = DNS:ldap.securecorp.local
EOF

openssl req -new -key ____ -subj "/C=ES/O=SecureCorp/CN=____" -out ldap.csr
openssl req -new -key ____ -subj "/C=ES/O=SecureCorp/CN=____" -out ldap.csr
# 2 · La petición. El CN es el NOMBRE con el que los clientes llaman al servidor
openssl req -new -key ____ -subj "/C=ES/O=SecureCorp/CN=____" -out ldap.csr
# 3 · La CA firma la petición (necesita el certificado Y la clave de la CA)
openssl x509 -req -in ____ -CA ____ -CAkey ____ -CAcreateserial -days 825 -sha256 -extfile ldap.ext -out ldap.crt
# Generar CSR:
openssl req -new -key ldap.key -subj "/C=ES/O=SecureCorp/CN=ldap.securecorp.local" -out ldap.csr
# Firmar con la CA:
openssl x509 -req -in ldap.csr -CA /pki/ca/ca.crt -CAkey /pki/ca/ca.key   -CAcreateserial -days 825 -sha256 -extfile ldap.ext -out ldap.crt
openssl verify -CAfile /pki/ca/ca.crt ldap.crt
exit
mkdir -p /etc/ldap/tls
cp /pki/ca/ca.crt /pki/servidor/ldap.crt /pki/servidor/ldap.key /etc/ldap/tls/
chown -R openldap:openldap /etc/ldap/tls
chmod 600 /etc/ldap/tls/ldap.key
ls -l /etc/ldap/tls
cat /ldif/03-tls.ldif
nano /ldif/03-tls.ldif
ldapmodify -Y EXTERNAL -H ldapi:/// -f /ldif/03-tls.ldif
nano /etc/default/slapd
exit
kdb5_util create -s -r SECURECORP.LOCAL    # Introduce una clave maestra
service krb5-kdc start
kadmin.local -q "addprinc lromero"
kadmin.local -q "addprinc -randkey host/web.securecorp.local"
kadmin.local -q "addprinc TUUSUARIO"
kadmin.local -q "delete_principal -force TUUSUARIO"
kadmin.local -q "addprinc peperodriguezcam"
kadmin.local -q "addprinc peperodriguezcam"
kadmin.local -q "addprinc mtorres"
exit
kadmin.local -q "addprinc mtorres"
exit
kvno host/web.securecorp.local
exit
exit
kadmin.local -q "modprinc -disallow_ALL_TIX mtorres"
kinit mtorres
exit
kadmin.local -q "modprinc -disallow_ALL_TIX mtorres"
exit
kadmin.local -q "modprinc -disallow_ALL_TIX mtorres"
exit
kadmin.local -q "modprinc +disallow_ALL_TIX mtorres"
kadmin.local -q "getprinc mtorres"
exit
